-- Insert a message and today's date (30/01/2025)
INSERT INTO Hallmark (message, date)
VALUES ('Hi im bhargav and this is sql script of date ', '2024-09-20');