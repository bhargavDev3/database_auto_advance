-- Create the table Hallmark
CREATE TABLE Hallmark (
    message VARCHAR(255),
    date DATE
);

---- Insert a message and today's date (30/01/2025)
--INSERT INTO Hallmark (message, date)
--VALUES ('Your message here', '2025-01-30');
